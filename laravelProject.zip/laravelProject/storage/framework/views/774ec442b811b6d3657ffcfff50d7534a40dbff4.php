<?php $__env->startSection('title', 'Add employee'); ?>


<?php $__env->startSection('content'); ?>
     <form action="/employees" method="POST" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <div class="form-group">
        <label for="firstname">First name:</label>
        <input type="text" class="form-control" id="firstname" name="firstname">
      </div>

      <div class="form-group">
        <label for="lasttname">Last name:</label>
        <input type="text" class="form-control" id="lastname" name="lastname">
      </div>
     



   
      <div class="form-group">
        <label for="image">Image</label>
        <input type="file" name="image">
      </div>
      <button type="submit" class="btn btn-default">Add Employee</button>
    </form> 
    <?php if(count($errors)): ?>
    <div class="alert alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>