<?php $__env->startSection('title', 'Employee Page'); ?>


<?php $__env->startSection('content'); ?>
    <h1><?php echo e($employee->firstname); ?></h1>
    <h1><?php echo e($employee->lastname); ?></h1>



    <h1>Users</h1>
    <ul>
      <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($user->name); ?></li>
      <li><?php echo e($user->email); ?></li>
      <li><?php echo e($user->created_at); ?></li>
      <li><?php echo e($user->updated_at); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <h2>Add Comment</h2>
    <form action="/employee/show/<?php echo e($employee->id); ?>" method="POST">
      <?php echo e(csrf_field()); ?>


      <div class="form-group">
        <label for="name">Name:</label>
        <input type="text" class="form-control" id="name" name="name">
      </div>

      <div class="form-group">
        <label for="email">Email:</label>
        <input type="text" class="form-control" id="email" name="email">
      </div>

      <div class="form-group">
        <label for="password">Password:</label>
        <input type="text" class="form-control" id="password" name="password">
      </div>

      <button type="submit" class="btn btn-info">Add User</button>
    </form> 
    <?php if(count($errors)): ?>
    <div class="alert alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>