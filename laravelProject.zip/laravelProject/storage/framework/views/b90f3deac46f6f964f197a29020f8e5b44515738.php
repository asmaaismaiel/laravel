<?php $__env->startSection('title', 'EditEmployee'); ?>


<?php $__env->startSection('content'); ?>
     <form action="/employees/edit/<?php echo e($employee->id); ?>" method="POST">
      <?php echo e(csrf_field()); ?>

      <div class="form-group">
        <label for="firstname">First name:</label>
        <input type="text" class="form-control" id="firstname" name="firstname" value="<?php echo e($employee->firstname); ?>">
      </div>

        <div class="form-group">
        <label for="firstname">Last name:</label>
        <input type="text" class="form-control" id="lastname" name="lastname" value="<?php echo e($employee->lastname); ?>">
      </div>

      <button type="submit" class="btn btn-info">Edit employee</button>
    </form> 
    <?php if(count($errors)): ?>
    <div class="alert alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>