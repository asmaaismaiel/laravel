<?php $__env->startSection('title', 'Employee Page'); ?>


<?php $__env->startSection('content'); ?>
    <table class="table table-hover">
    	<tr>
    		<th>First name</th>	
            <th>Last name</th>	
            <th>Date</th>
    	</tr>
    	<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    	<tr>
    		<td><a href="employees/show/<?php echo e($employee->id); ?>"><?php echo e($employee->firstname); ?></a></td>
            <td><a href="employees/show/<?php echo e($employee->id); ?>"><?php echo e($employee->lastname); ?></a></td>
            <td><?php echo e($employee->created_at->diffForHumans(carbon\carbon::now())); ?></td>
            <td><img src="<?php echo e(Storage::disk('local')->url($employee->image)); ?>" height="100px" width="100px" /></td>
            <td><a href="employees/edit/<?php echo e($employee->id); ?>" class="btn btn-info">Edit</a></td>
            <td><a href="employees/delete/<?php echo e($employee->id); ?>" class="btn btn-danger">Delete</a></td>
    	</tr>
    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>