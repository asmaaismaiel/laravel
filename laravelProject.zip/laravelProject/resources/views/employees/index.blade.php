@extends('layouts.master')

@section('title', 'Employee Page')


@section('content')
    <table class="table table-hover">
    	<tr>
    		<th>First name</th>	
            <th>Last name</th>	
            <th>Date</th>
    	</tr>
    	@foreach($employees as $id=>$employee)
    	<tr>
    		<td><a href="employees/show/{{$employee->id}}">{{$employee->firstname}}</a></td>
            <td><a href="employees/show/{{$employee->id}}">{{$employee->lastname}}</a></td>
            <td>{{$employee->created_at->diffForHumans(carbon\carbon::now())}}</td>
            <td><img src="{{Storage::disk('local')->url($employee->image)}}" height="100px" width="100px" /></td>
            <td><a href="employees/edit/{{$employee->id}}" class="btn btn-info">Edit</a></td>
            <td><a href="employees/delete/{{$employee->id}}" class="btn btn-danger">Delete</a></td>
    	</tr>
    	@endforeach
    </table>
@stop