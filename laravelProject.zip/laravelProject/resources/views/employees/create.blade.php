@extends('layouts.master')

@section('title', 'Add employee')


@section('content')
     <form action="/employees" method="POST" enctype="multipart/form-data">
      {{csrf_field()}}
      <div class="form-group">
        <label for="firstname">First name:</label>
        <input type="text" class="form-control" id="firstname" name="firstname">
      </div>

      <div class="form-group">
        <label for="lasttname">Last name:</label>
        <input type="text" class="form-control" id="lastname" name="lastname">
      </div>
     



   
      <div class="form-group">
        <label for="image">Image</label>
        <input type="file" name="image">
      </div>
      <button type="submit" class="btn btn-default">Add Employee</button>
    </form> 
    @if(count($errors))
    <div class="alert alert-danger">
      <ul>
        @foreach($errors->all() as $key=>$error)
        <li>{{$error}}</li>
        @endforeach
      </ul>
    </div>
    @endif
@stop