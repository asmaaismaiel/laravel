@extends('layouts.master')

@section('title', 'EditEmployee')


@section('content')
     <form action="/employees/edit/{{$employee->id}}" method="POST">
      {{csrf_field()}}
      <div class="form-group">
        <label for="firstname">First name:</label>
        <input type="text" class="form-control" id="firstname" name="firstname" value="{{$employee->firstname}}">
      </div>

        <div class="form-group">
        <label for="firstname">Last name:</label>
        <input type="text" class="form-control" id="lastname" name="lastname" value="{{$employee->lastname}}">
      </div>

      <button type="submit" class="btn btn-info">Edit employee</button>
    </form> 
    @if(count($errors))
    <div class="alert alert-danger">
      <ul>
        @foreach($errors->all() as $key=>$error)
        <li>{{$error}}</li>
        @endforeach
      </ul>
    </div>
    @endif
@stop