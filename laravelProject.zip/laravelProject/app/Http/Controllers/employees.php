<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


use App;
use App\Employee; 
use App\User;
class employees extends Controller
{
 
    public function index(){
    	$employees = App\Employee::all();
    	return view('employees.index',compact('employees'));
    }

    public function create(){
    	return view('employees.create');
    }

    public function store(Request $request){
        $image = "";
        if($request->hasFile('image')){
            $image = $request->image->store('public');
        }
        $this->validate(request(),
            [
                'firstname'=>'required|min:2',
                'lastname'=>'required|min:2'
         ]);

    	$newEmployee = new Employee;
    	$newEmployee->firstname = request('firstname');
    	$newEmployee->lastname = request('lastname');
        $newEmployee->image = $image;
    	
    	$newEmployee->save();
    	return redirect('employees');
    }


    public function show($id){
    	$employee = App\Employee::find($id);
        $user = $employee->user;
    	return view('employees.show',compact("employee","user"));	
    }

    public function edit($id){
        $employee = App\Employee::find($id);
    	
    	return view('employees.edit',compact("employee"));
    }



    public function update($id){
        $this->validate(request(),
            [
                'firstname'=>'required|min:2',
                'lastname'=>'required|min:2'
            
         ]);

        $employee = App\Employee::find($id);
        $employee->firstname = request('firstname');
    	$employee->lastname = request('lastname');
    	$employee->save();
    	return redirect('employees');
    }



  private function doSearchingQuery($constraints) {
        $query = DB::table('employees')
        ->select('employees.firstname as employee_name', 'employees.*');
        $fields = array_keys($constraints);
        $index = 0;
        foreach ($constraints as $constraint) {
            if ($constraint != null) {
                $query = $query->where($fields[$index], 'like', '%'.$constraint.'%');
            }

            $index++;
        }
        return $query->paginate(5);
    }

    public function search(Request $request) {
        $constraints = [
            'firstname' => $request['firstname'],
            ];
        $employees = $this->doSearchingQuery($constraints);
        $constraints['firstname'] = $request['firstname'];
        return view('employees/index', ['employees' => $employees, 'searchingVals' => $constraints]);
    }


/*public function search(Request $request) {
        $constraints = [
            'firstname' => $request['firstname'],
            'department.name' => $request['department_name']
            ];
        $employees = $this->doSearchingQuery($constraints);
        $constraints['department_name'] = $request['department_name'];
        return view('employees-mgmt/index', ['employees' => $employees, 'searchingVals' => $constraints]);
    }

    private function doSearchingQuery($constraints) {
        $query = DB::table('employees')
        ->leftJoin('city', 'employees.city_id', '=', 'city.id')
        ->leftJoin('department', 'employees.department_id', '=', 'department.id')
        ->leftJoin('state', 'employees.state_id', '=', 'state.id')
        ->leftJoin('country', 'employees.country_id', '=', 'country.id')
        ->leftJoin('division', 'employees.division_id', '=', 'division.id')
        ->select('employees.firstname as employee_name', 'employees.*','department.name as department_name', 'department.id as department_id', 'division.name as division_name', 'division.id as division_id');
        $fields = array_keys($constraints);
        $index = 0;
        foreach ($constraints as $constraint) {
            if ($constraint != null) {
                $query = $query->where($fields[$index], 'like', '%'.$constraint.'%');
            }

            $index++;
        }
        return $query->paginate(5);
    }


*/


    public function destroy($id){
        $employee = App\Employee::find($id);

    
    	$employee->delete();
    	return redirect('employees');
    }
 
    //

}
